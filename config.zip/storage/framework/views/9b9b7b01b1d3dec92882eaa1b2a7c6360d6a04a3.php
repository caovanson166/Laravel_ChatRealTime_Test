<html>

<head>
    <title>Demo chat</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
    <div id="data">
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p id="<?php echo e($message->id); ?>"><strong><?php echo e($message->author); ?></strong>: <?php echo e($message->content); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div>
        <form action="send-message" method="POST">
        <?php echo e(csrf_field()); ?>

        Name: <input type="text" name="author">
        <br>
        <br>
        Content: <textarea name="content" rows="5" style="width:100%"></textarea>
        <button type="submit" name="send">Send</button>
        </form>
        <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.0.1/socket.io.js"></script>
        <script>
            //,{ transports: ['websocket', 'polling', 'flashsocket'] }
        var socket = io('http://<?php echo e(Request::getHost()); ?>:6001')
        socket.on('laravel_database_chat:message',function(data){
            console.log(data)
            if($('#'+data.id).length == 0){
                $('#data').append('<p><strong>'+data.author+'</strong>: '+data.content+'</p>')
            }
            else{
                console.log('Đã có tin nhắn')
            }
        })

        </script>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\example-app\resources\views/messages.blade.php ENDPATH**/ ?>